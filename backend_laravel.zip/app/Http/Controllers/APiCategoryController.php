<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class APiCategoryController extends Controller
{
    //
}
